package com.tamiuz.arwina.main;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tamiuz.arwina.MenuActivities.communications.AboutUsActivity;
import com.tamiuz.arwina.MenuActivities.communications.ConditionsActivity;
import com.tamiuz.arwina.MenuActivities.communications.ContactUsActivity;
import com.tamiuz.arwina.MenuActivities.communications.PrivacyPolicyActivity;
import com.tamiuz.arwina.MenuActivities.payment.PaymentActivity;
import com.tamiuz.arwina.Models.AllCompaniesModel;
import com.tamiuz.arwina.Models.SettingsInfoModel;
import com.tamiuz.arwina.Models.UserModel;
import com.tamiuz.arwina.R;
import com.tamiuz.arwina.networking.ApiClient;
import com.tamiuz.arwina.networking.ApiServiceInterface;
import com.tamiuz.arwina.networking.NetworkAvailable;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    @BindView(R.id.nv)
    NavigationView navigationView;
    @BindView(R.id.main_noData_txtV_id)
    TextView no_data_txtV;
    @BindView(R.id.main_progress_id)
    ProgressBar main_progressBar;
    @BindView(R.id.mainCompanies_recyclerV_id)
    RecyclerView main_recyclerV;

    private DrawerLayout drawer;
    private NetworkAvailable networkAvailable;
    private MainRecyclerAdapter adapter;
    public static UserModel userModel;
    List<SettingsInfoModel.InfoDataModel> infoDataModelList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        // Tool Bar
        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        // Tint progressBar...
        main_progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.MULTIPLY);

        if (getIntent().hasExtra("user_data")) {
            userModel = getIntent().getParcelableExtra("user_data");
        }
        networkAvailable = new NetworkAvailable(this);
        if (networkAvailable.isNetworkAvailable()) {
            getCompaniesData();
            getSettingInfoo();
        } else {
            Toast.makeText(this, getString(R.string.error_connection), Toast.LENGTH_LONG).show();
        }
        NavigationView navigationView = findViewById(R.id.nv);
        navigationView.setNavigationItemSelectedListener(this);
    }

    private void getSettingInfoo() {
        ApiServiceInterface serviceInterface = ApiClient.getClient().create(ApiServiceInterface.class);
        Call<SettingsInfoModel> call = serviceInterface.getSettingsInfo();
        call.enqueue(new Callback<SettingsInfoModel>() {
            @Override
            public void onResponse(Call<SettingsInfoModel> call, Response<SettingsInfoModel> response) {
                if (response.body().getMessage()) {
                    infoDataModelList = response.body().getData();
                }
            }

            @Override
            public void onFailure(Call<SettingsInfoModel> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void getCompaniesData() {
        main_progressBar.setVisibility(View.VISIBLE);
        ApiServiceInterface serviceInterface = ApiClient.getClient().create(ApiServiceInterface.class);
        Call<AllCompaniesModel> call = serviceInterface.getAllCompanies();
        call.enqueue(new Callback<AllCompaniesModel>() {
            @Override
            public void onResponse(Call<AllCompaniesModel> call, Response<AllCompaniesModel> response) {
                if (response.body().getMessage()) {
                    List<AllCompaniesModel.CompanyData> companyDataList = response.body().getData();
                    main_recyclerV.setVisibility(View.VISIBLE);
                    no_data_txtV.setVisibility(View.GONE);
                    buildCompaniesRecycler(companyDataList);
                } else {
                    no_data_txtV.setVisibility(View.VISIBLE);
                    main_recyclerV.setVisibility(View.GONE);
                }
                main_progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<AllCompaniesModel> call, Throwable t) {
                t.printStackTrace();
                main_progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void buildCompaniesRecycler(List<AllCompaniesModel.CompanyData> companyDataList) {
        main_recyclerV.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        main_recyclerV.setHasFixedSize(true);
        // setAdapter
        adapter = new MainRecyclerAdapter(MainActivity.this, companyDataList);
        main_recyclerV.setAdapter(adapter);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        Intent intent = null;
        if (id == R.id.nav_payment) {
            intent = new Intent(MainActivity.this, PaymentActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_aboutApp) {
            intent = new Intent(MainActivity.this, AboutUsActivity.class);
            intent.putExtra("about_data", infoDataModelList.get(0).getArabout());
            startActivity(intent);
        } else if (id == R.id.nav_termsAndConditions) {
            startActivity(new Intent(MainActivity.this, ConditionsActivity.class));

        } else if (id == R.id.nav_privacyPolicy) {
            intent = new Intent(MainActivity.this, PrivacyPolicyActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_contactUs) {
            intent = new Intent(MainActivity.this, ContactUsActivity.class);
            startActivity(intent);
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
