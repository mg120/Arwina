package com.tamiuz.arwina.MenuActivities.profile;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.tamiuz.arwina.MenuActivities.notifications.MyNotifications;
import com.tamiuz.arwina.R;
import com.tamiuz.arwina.main.AddProduct.MyProducts;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ProfileActivity extends AppCompatActivity {

    @BindView(R.id.profile_name_txtV_id)
    TextView title_txtV;
    @BindView(R.id.profile_user_imageV_id)
    ImageView user_imageV;

    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        ButterKnife.bind(this);

    }

    @OnClick(R.id.profile_notifications_imageV_id)
    void goToNotifications() {
        intent = new Intent(ProfileActivity.this, MyNotifications.class);
        startActivity(intent);
    }

    @OnClick(R.id.profile_back_txtV_id)
    void goBack() {
        finish();
    }

    @OnClick(R.id.profile_orders_cardLayout_id)
    void goToOrders() {
        intent = new Intent(ProfileActivity.this, MyOrders.class);
        startActivity(intent);
    }

    @OnClick(R.id.profile_products_cardLayout_id)
    void goToProducts() {
        intent = new Intent(ProfileActivity.this, MyProducts.class);
        startActivity(intent);
    }

    @OnClick(R.id.profile_products_cardLayout_id)
    void goToWallet() {
//        intent = new Intent(ProfileActivity.this, MyProducts.class);
//        startActivity(intent);
    }

    @OnClick(R.id.profile_update_cardLayout_id)
    void updateProfileData() {
        intent = new Intent(ProfileActivity.this, EditProfileActivity.class);
        startActivity(intent);
    }
}
