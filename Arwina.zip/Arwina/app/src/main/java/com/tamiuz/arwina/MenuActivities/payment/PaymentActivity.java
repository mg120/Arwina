package com.tamiuz.arwina.MenuActivities.payment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.tamiuz.arwina.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class PaymentActivity extends AppCompatActivity {

    @BindView(R.id.receivingPayment__imageV_icon)
    ImageView receivingPayment_imageV;
    @BindView(R.id.visaPayment_imageV_icon)
    ImageView visaPayment_imageV;

    private int payment_type = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        ButterKnife.bind(this);

    }

    @OnClick(R.id.visaPayment_cardlayout_language)
    void visaClicked() {
        payment_type = 1;
        receivingPayment_imageV.setVisibility(View.GONE);
        visaPayment_imageV.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.receivingPayment_cardlayout_language)
    void deliveredClicked() {
        payment_type = 0;
        receivingPayment_imageV.setVisibility(View.VISIBLE);
        visaPayment_imageV.setVisibility(View.GONE);
    }

    @OnClick(R.id.continue_payment_btn_id)
    void conrinuePayment(){
        if (payment_type == 0){

        } else if (payment_type == 1){

        }
    }
}
