package com.tamiuz.arwina.MenuActivities.communications;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.tamiuz.arwina.R;

public class ConditionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conditions);
    }
}
