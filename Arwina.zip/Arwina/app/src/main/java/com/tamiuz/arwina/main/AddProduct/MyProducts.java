package com.tamiuz.arwina.main.AddProduct;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tamiuz.arwina.R;
import com.tamiuz.arwina.networking.NetworkAvailable;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MyProducts extends AppCompatActivity {

    @BindView(R.id.products_recyclerV_id)
    RecyclerView recyclerView;
    @BindView(R.id.products_progressBar_id)
    ProgressBar progressBar;
    @BindView(R.id.products_noData_txtV_id)
    TextView noData_txtV;

    private NetworkAvailable networkAvailable;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_products);
        ButterKnife.bind(this);

    }

    @OnClick(R.id.products_back_txtV_id)
    void goBack(){
        finish();
    }
}
