package com.tamiuz.arwina.main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.tamiuz.arwina.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CompanyProducts extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_products);
        ButterKnife.bind(this);

    }
}
