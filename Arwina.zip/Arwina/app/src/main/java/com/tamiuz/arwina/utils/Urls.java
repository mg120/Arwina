package com.tamiuz.arwina.utils;

/**
 * Created by Ma7MouD on 9/18/2018.
 */

public class Urls {

    public final static String BASE_URL = "http://eltamiuz.net/Arwina/";

    public static String imagesBase_Url = "http://eltamiuz.net/Arwina/users/images/";
}
