package com.tamiuz.arwina.main;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.media.Rating;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.tamiuz.arwina.Models.AllCompaniesModel;
import com.tamiuz.arwina.R;
import com.tamiuz.arwina.utils.Urls;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainRecyclerAdapter extends RecyclerView.Adapter<MainRecyclerAdapter.ViewHolder> {

    private Context mContext;
    private List<AllCompaniesModel.CompanyData> list;

    public MainRecyclerAdapter(Context mContext, List<AllCompaniesModel.CompanyData> list) {
        this.mContext = mContext;
        this.list = list;
    }

    @NonNull
    @Override
    public MainRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.main_company_row_item, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MainRecyclerAdapter.ViewHolder viewHolder, int position) {
        viewHolder.company_name.setText(list.get(position).getName());
        viewHolder.company_address.setText(list.get(position).getAddress());
//        viewHolder.company_ratingBar.setRating(list.get(position).get);
        Glide.with(mContext)
                .load(Urls.imagesBase_Url + list.get(position).getImage())
                .placeholder(R.drawable.product)
                .error(R.drawable.product)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        viewHolder.progressBar.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        viewHolder.progressBar.setVisibility(View.GONE);
                        return true;
                    }
                })
                .into(viewHolder.company_imageV);
    }

    @Override
    public int getItemCount() {
        return 4;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.company_row_imageV_id)
        ImageView company_imageV;
        @BindView(R.id.company_name_txtV_id)
        TextView company_name;
        @BindView(R.id.company_address_txtV_id)
        TextView company_address;
        @BindView(R.id.company_ratingBar_item_id)
        RatingBar company_ratingBar;
        @BindView(R.id.company_image_progress_id)
        ProgressBar progressBar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
