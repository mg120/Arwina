package com.tamiuz.arwina.MenuActivities.notifications;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tamiuz.arwina.R;
import com.tamiuz.arwina.networking.NetworkAvailable;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MyNotifications extends AppCompatActivity {

    @BindView(R.id.notifications_recyclerV_id)
    RecyclerView recyclerView;
    @BindView(R.id.notifications_progressBar_id)
    ProgressBar progressBar;
    @BindView(R.id.notifications_noData_txtV_id)
    TextView noData_txtV;

    private NetworkAvailable networkAvailable;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_notifications);
        ButterKnife.bind(this);

        networkAvailable = new NetworkAvailable(this);
        if (networkAvailable.isNetworkAvailable()){

        } else
            Toast.makeText(this, getString(R.string.error_connection), Toast.LENGTH_SHORT).show();
    }

    @OnClick(R.id.notifications_back_txtV_id)
    void goBack(){
        finish();
    }
}
