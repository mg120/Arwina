package com.tamiuz.arwina.loginAndRegister;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import com.fourhcode.forhutils.FUtilsValidation;
import com.google.gson.Gson;
import com.tamiuz.arwina.Models.UserLoginModel;
import com.tamiuz.arwina.Models.UserModel;
import com.tamiuz.arwina.R;
import com.tamiuz.arwina.main.MainActivity;
import com.tamiuz.arwina.networking.ApiClient;
import com.tamiuz.arwina.networking.ApiServiceInterface;
import com.tamiuz.arwina.networking.NetworkAvailable;
import com.tamiuz.arwina.utils.DialogUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LogInActivity extends AppCompatActivity {

    @BindView(R.id.login_phoneNum_ed_id)
    EditText phone_ed;
    @BindView(R.id.login_password_ed_id)
    EditText password_ed;

    private Intent intent;
    private NetworkAvailable networkAvailable;
    private DialogUtil dialogUtil;
    private UserModel userModel;
    private final String TAG = this.getClass().getSimpleName();
    // Sahred Pref
    // put data to shared preferences ...
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences;
    public static final String MY_PREFS_NAME = "all_user_data";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        ButterKnife.bind(this);

        networkAvailable = new NetworkAvailable(this);
        dialogUtil = new DialogUtil();
    }

    @OnClick(R.id.newUser_txtV_id)
    void newSign() {
        intent = new Intent(LogInActivity.this, SignUpTypeActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.forgetPassword_txtV_id)
    void forgetPass() {
        intent = new Intent(LogInActivity.this, ForgetPasswordActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.lgoin_btn_id)
    void userLogin() {
        if (networkAvailable.isNetworkAvailable()) {
            if (!FUtilsValidation.isEmpty(phone_ed, getString(R.string.required))
                    && !FUtilsValidation.isEmpty(password_ed, getString(R.string.required))) {
                if (password_ed.getText().toString().length() < 6) {
                    password_ed.setError(getResources().getString(R.string.pass_is_weak));
                    password_ed.requestFocus();
                    return;
                }
                String token = "123456";
                // Show Progress Dialog
                final ProgressDialog dialog = dialogUtil.showProgressDialog(LogInActivity.this, getString(R.string.logining), false);
                ApiServiceInterface serviceInterface = ApiClient.getClient().create(ApiServiceInterface.class);
                Call<UserLoginModel> call = serviceInterface.userLogin(phone_ed.getText().toString(), password_ed.getText().toString(), token);
                call.enqueue(new Callback<UserLoginModel>() {
                    @Override
                    public void onResponse(Call<UserLoginModel> call, Response<UserLoginModel> response) {
                        Log.i(TAG, "onResponse " + response.toString());
                        dialog.dismiss();
                        userModel = new UserModel();
                        if (response.body().getMessage()){
                            UserLoginModel.LoginDataObj loginDataObj = response.body().getData();
                            userModel.setId(loginDataObj.getId());
                            userModel.setRole(loginDataObj.getRole());
                            userModel.setName(loginDataObj.getName());
                            userModel.setPhone(loginDataObj.getPhone());
                            userModel.setAddress(loginDataObj.getAddress());
                            userModel.setCommercialreg(loginDataObj.getCommercialreg());
                            userModel.setCommercialregno(loginDataObj.getCommercialregno());
                            userModel.setHavedelivery(loginDataObj.getHavedelivery());
                            userModel.setImage(loginDataObj.getImage());

                            // Convert User Data to Gon OBJECT ...
                            Gson gson = new Gson();
                            String user_data = gson.toJson(userModel);
                            editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                            editor.putString("user_data", user_data);
                            editor.commit();

                            // GoTo Main Activity...
                            Intent intent = new Intent(LogInActivity.this, MainActivity.class);
                            intent.putExtra("user_data" , userModel);
                            startActivity(intent);
                        }
                    }

                    @Override
                    public void onFailure(Call<UserLoginModel> call, Throwable t) {
                        Log.i(TAG, "onFailure " + t.getMessage());
                        t.printStackTrace();
                        dialog.dismiss();
                        Toast.makeText(LogInActivity.this, getString(R.string.plz_check_data), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            Toast.makeText(this, getString(R.string.error_connection), Toast.LENGTH_SHORT).show();
        }
    }
}
