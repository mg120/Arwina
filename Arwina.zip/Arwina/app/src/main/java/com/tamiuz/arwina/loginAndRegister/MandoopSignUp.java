package com.tamiuz.arwina.loginAndRegister;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import com.fourhcode.forhutils.FUtilsValidation;
import com.tamiuz.arwina.Models.RegisterResponseModel;
import com.tamiuz.arwina.Models.UserModel;
import com.tamiuz.arwina.R;
import com.tamiuz.arwina.main.MainActivity;
import com.tamiuz.arwina.networking.ApiClient;
import com.tamiuz.arwina.networking.ApiServiceInterface;
import com.tamiuz.arwina.networking.NetworkAvailable;
import com.tamiuz.arwina.utils.DialogUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MandoopSignUp extends AppCompatActivity {

    @BindView(R.id.mandoop_name_ed_id)
    EditText userNam_ed;
    @BindView(R.id.mandoop_phone_ed_id)
    EditText phone_ed;
    @BindView(R.id.mandoop_password_ed_id)
    EditText password_ed;

    private int sign_type;
    private String commercialreg, commercialregno, address, havedelivery = "";
    private MultipartBody.Part body = null;
    private UserModel userModel;
    private NetworkAvailable networkAvailable;
    private DialogUtil dialogUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mandoop_sign_up);
        ButterKnife.bind(this);

        networkAvailable = new NetworkAvailable(this);
        dialogUtil = new DialogUtil();
        if (getIntent().hasExtra("sign_type")) {
            sign_type = getIntent().getExtras().getInt("sign_type");
            Log.i("sign_type", sign_type + "");
        }
    }

    @OnClick(R.id.company_sign_btn_id)
    void mandoopSignUp(){
        if (networkAvailable.isNetworkAvailable()) {
            if (!FUtilsValidation.isEmpty(userNam_ed, getString(R.string.required))
                    && !FUtilsValidation.isEmpty(phone_ed, getString(R.string.required))
                    && !FUtilsValidation.isEmpty(password_ed, getString(R.string.required))
            ) {
                // Show Progress Dialog
                final ProgressDialog dialog = dialogUtil.showProgressDialog(MandoopSignUp.this, getString(R.string.signing_up), false);
                userModel = new UserModel();
                String token = "123456";
                RequestBody NamePart = RequestBody.create(MultipartBody.FORM, userNam_ed.getText().toString().trim());
                ApiServiceInterface serviceInterface = ApiClient.getClient().create(ApiServiceInterface.class);
                Call<RegisterResponseModel> call = serviceInterface.register(sign_type, NamePart, phone_ed.getText().toString(), password_ed.getText().toString(), commercialreg, commercialregno, address, havedelivery, token, body);
                call.enqueue(new Callback<RegisterResponseModel>() {
                    @Override
                    public void onResponse(Call<RegisterResponseModel> call, Response<RegisterResponseModel> response) {
                        if (response.body().getMessage()) {
                            dialog.dismiss();
                            RegisterResponseModel.LoginDataObj loginDataObj = response.body().getData();
                            userModel.setId(loginDataObj.getId());
                            userModel.setRole(loginDataObj.getRole());
                            userModel.setName(loginDataObj.getName());
                            userModel.setPhone(loginDataObj.getPhone());

                            // GoTo Main Activity...
                            Toast.makeText(MandoopSignUp.this, getString(R.string.registered_successfully), Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MandoopSignUp.this, MainActivity.class);
                            intent.putExtra("user_data", userModel);
                            startActivity(intent);
                        } else {
                            dialog.dismiss();
                            Toast.makeText(MandoopSignUp.this, getString(R.string.phone_already_taken), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<RegisterResponseModel> call, Throwable t) {
                        t.printStackTrace();
                        dialog.dismiss();
                        Toast.makeText(MandoopSignUp.this, getString(R.string.phone_already_taken), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else
            Toast.makeText(this, getString(R.string.error_connection), Toast.LENGTH_SHORT).show();
    }
}
