package com.tamiuz.arwina.MenuActivities.communications;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.URLUtil;
import android.widget.TextView;
import android.widget.Toast;

import com.tamiuz.arwina.Models.SettingsInfoModel;
import com.tamiuz.arwina.R;
import com.tamiuz.arwina.networking.ApiClient;
import com.tamiuz.arwina.networking.ApiServiceInterface;
import com.tamiuz.arwina.networking.NetworkAvailable;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AboutUsActivity extends AppCompatActivity {

    @BindView(R.id.aboutContent_txtV_id)
    TextView aboutApp_txtV;

    private NetworkAvailable networkAvailable;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        ButterKnife.bind(this);

        networkAvailable = new NetworkAvailable(this);

        if (getIntent().hasExtra("about_data")){

            String about_txt = getIntent().getStringExtra("about_data");
            aboutApp_txtV.setText(about_txt);
        }


//        if (networkAvailable.isNetworkAvailable()){
//            getAboutData();
//        } else
//            Toast.makeText(this, getString(R.string.error_connection), Toast.LENGTH_SHORT).show();
    }

    private void getAboutData() {
        ApiServiceInterface serviceInterface = ApiClient.getClient().create(ApiServiceInterface.class);
        Call<SettingsInfoModel> call = serviceInterface.getSettingsInfo();
        call.enqueue(new Callback<SettingsInfoModel>() {
            @Override
            public void onResponse(Call<SettingsInfoModel> call, Response<SettingsInfoModel> response) {
                SettingsInfoModel settingsInfoModel = response.body();
            }

            @Override
            public void onFailure(Call<SettingsInfoModel> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @OnClick(R.id.aboutApp_back_txtV_id)
    void goBack() {
        finish();
    }

    @OnClick(R.id.aboutApp_notifications_imageV_id)
    void goToNotifications() {
        Toast.makeText(this, "Notifications", Toast.LENGTH_SHORT).show();
    }

    @OnClick(R.id.about_youtube_imageV_id)
    void youtubeClicked(){

    }
    @OnClick(R.id.about_instgram_imageV_id)
    void instgramClicked(){

    }
    @OnClick(R.id.about_twetter_imageV_id)
    void twitterClicked(){

    }
    @OnClick(R.id.about_facebook_imageV_id)
    void faceBookClicked(){

    }

    public static void openWebPage(Context context, String url) {
        try {
            if (!URLUtil.isValidUrl(url)) {
                Toast.makeText(context, " This is not a valid link", Toast.LENGTH_LONG).show();
            } else {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                context.startActivity(intent);
            }
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, " You don't have any browser to open web page", Toast.LENGTH_LONG).show();
        }
    }
}
