package com.tamiuz.arwina.networking;


import com.tamiuz.arwina.Models.AllCompaniesModel;
import com.tamiuz.arwina.Models.ContactUsResponseModel;
import com.tamiuz.arwina.Models.RegisterResponseModel;
import com.tamiuz.arwina.Models.SettingsInfoModel;
import com.tamiuz.arwina.Models.UserLoginModel;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;


public interface ApiServiceInterface {

    // ---------------- LogIn -------------------------------
    @FormUrlEncoded
    @POST("api/login")
    Call<UserLoginModel> userLogin(@Field("phone") String phone,
                                   @Field("password") String password,
                                   @Field("firebase_token") String firebase_token);

    // ---------------- Regsiter -----------------------------
    @Multipart
    @POST("api/register")
    Call<RegisterResponseModel> register(@Query("role") int role,
                                         @Part("name") RequestBody name,
                                         @Query("phone") String phone,
                                         @Query("password") String password,
                                         @Query("commercialreg") String commercialreg,
                                         @Query("commercialregno") String commercialregno,
                                         @Query("address") String address,
                                         @Query("havedelivery") String havedelivery,
                                         @Query("firebase_token") String firebase_token,
                                         @Part MultipartBody.Part user_image);

    // ---------------- All Companies ---------------------------
    @POST("api/allcompanies")
    Call<AllCompaniesModel> getAllCompanies();


    // ---------------- My Products -----------------------------
    @FormUrlEncoded
    @POST("api/myitems")
    Call<AllCompaniesModel> getMyProducts(@Field("user_id") int user_id);



    // ---------------- Add Product ------------------------------
    @FormUrlEncoded
    @POST("api/saveitem")
    Call<AllCompaniesModel> add_product(@Field("trader_id") int trader_id,
                                        @Part("title") RequestBody title,
                                        @Field("qty") String qty,
                                        @Field("maxqty") String maxqty,
                                        @Field("address") String address,
                                        @Field("desc") String desc,
                                        @Field("price") String price,
                                        @Part MultipartBody.Part user_image );


    // ---------------- Setting Info -----------------------------
    @POST("api/settinginfo")
    Call<SettingsInfoModel> getSettingsInfo();


    // ---------------- Contact Us -------------------------------
    @FormUrlEncoded
    @POST("api/contactus")
    Call<ContactUsResponseModel> contact_Message(@Field("name") String name,
                                                 @Field("phone") String phone,
                                                 @Field("message") String message);

}