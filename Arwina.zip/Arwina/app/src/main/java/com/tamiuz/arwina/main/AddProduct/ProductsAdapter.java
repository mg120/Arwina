package com.tamiuz.arwina.main.AddProduct;

import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tamiuz.arwina.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ViewHolder> {
    @NonNull
    @Override
    public ProductsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.product_item_row_layout, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductsAdapter.ViewHolder viewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.product_item_imageV_id)
        ImageView product_imageV;
        @BindView(R.id.product_edit_imageV_id)
        ImageView edit_imageV;
        @BindView(R.id.product_delete_imageV_id)
        ImageView delete_imageV;
        @BindView(R.id.product_name_txtV_is)
        TextView product_name_txtV;
        @BindView(R.id.product_price_txtV_id)
        TextView product_price_txtV;
        @BindView(R.id.product_content_txtV_id)
        TextView product_content_txtV;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
