package com.tamiuz.arwina.MenuActivities.profile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tamiuz.arwina.R;
import com.tamiuz.arwina.networking.NetworkAvailable;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MyOrders extends AppCompatActivity {

    @BindView(R.id.orders_recyclerV_id)
    RecyclerView orders_recyclerV;
    @BindView(R.id.no_orders_txtV_id)
    TextView no_orders_txtV;
    @BindView(R.id.orders_progressBar_id)
    ProgressBar progressBar;

    private NetworkAvailable networkAvailable;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_orders);
        ButterKnife.bind(this);

        networkAvailable = new NetworkAvailable(this);
    }

    @OnClick(R.id.orders_back_txtV_id)
    void goBack(){
        finish();
    }
}
